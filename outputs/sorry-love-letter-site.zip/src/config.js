export const CONTACT_CONFIG = {
  phone: 'YOUR_PHONE_NUMBER',
  whatsapp: 'YOUR_WHATSAPP_NUMBER',
  girlfriendName: 'Ishaaa'
};

export const LOVE_CONFIG = {
  girlfriendName: 'Ishaaa',
  yourName: 'Akash',
  heroTitle: 'I Owe You An Apology',
  heroText:
    "Yesterday didn't go the way I wish it had. I was rude, and I know my words and behavior may have hurt you. I don't want to make excuses. I just want to say I'm genuinely sorry.",
  heroNote:
    'This little website is my way of saying what I sometimes struggle to say out loud.',
  yesterdayText:
    "About yesterday, I want to be honest without dressing it up. I was rude. I let the moment come out in a way that was unfair to you, and that is on me. Even if there was confusion or emotion in the air, I still had a choice in how I spoke and how I behaved. I should have chosen patience. I should have chosen kindness. I regret that I didn't.",
  betterVersion: {
    before:
      'I reacted too quickly. I sounded colder than I should have, and I let my frustration speak before my care did.',
    after:
      "I should have slowed down, listened properly, and told you that your feelings mattered to me before trying to explain mine."
  },
  letterParagraphs: [
    "I'm sorry. Not in the quick, easy way people say it just to end a conversation, but in the real way. I know I was rude, and I know that may have made you feel hurt, unheard, or unimportant. That is not how I want you to feel with me.",
    "I don't want to justify what happened. I don't want to hide behind stress, mood, timing, or anything else. I care about you, and caring about you means taking responsibility when I handle something badly.",
    "You matter to me. Our relationship matters to me. The way I speak to you matters to me. I don't expect you to instantly forget yesterday, and I don't want to rush your feelings. I just want you to know that I regret hurting you.",
    "I want to communicate better. I want to listen more fully. I want to understand you before defending myself. I want to fix what I can, not just with words on a screen, but with how I show up after this.",
    "I love you. And when you're comfortable, I would really like us to talk."
  ],
  reasonsILoveYou: [
    'Your smile, because it can soften an entire day.',
    'The way you make ordinary moments feel like memories.',
    'Your kindness, especially in the small things you do without making a show of them.',
    'Your little habits that somehow became some of my favorite details.',
    'The way you understand parts of me I struggle to explain.',
    'The conversations we have, even the quiet ones.',
    "The memories we've already made and the ones I still hope we get to make.",
    'Your presence, because being around you feels like coming home.',
    'The way you remind me that love should be gentle.',
    'Simply being you, exactly as you are.'
  ],
  promises: [
    "Listen before reacting.",
    "Speak with kindness, even when I'm upset.",
    'Never let anger become an excuse for rudeness.',
    'Communicate instead of assuming.',
    'Give you space when you need it.',
    "Make sure disagreements don't become disrespect.",
    'Understand your feelings instead of immediately defending mine.'
  ],
  memories: [
    {
      title: 'The Beginning',
      description: 'YOUR_MEMORY_HERE'
    },
    {
      title: 'Our First Special Conversation',
      description: 'YOUR_MEMORY_HERE'
    },
    {
      title: 'A Favorite Memory',
      description: 'YOUR_MEMORY_HERE'
    },
    {
      title: 'A Moment That Made Me Fall Harder',
      description: 'YOUR_MEMORY_HERE'
    },
    {
      title: 'A Silly Moment',
      description: 'YOUR_MEMORY_HERE'
    },
    {
      title: 'A Difficult Moment We Got Through',
      description: 'YOUR_MEMORY_HERE'
    },
    {
      title: 'Today',
      description: 'I was wrong to be rude. I am sorry, and I want to do better.'
    }
  ],
  smileMessages: [
    "You're still my favorite person.",
    "I hope you're smiling right now.",
    "You're more special to me than I sometimes know how to explain.",
    "One bad day doesn't erase all our beautiful moments.",
    'I love you.',
    "And yes, I'm still sorry.",
    'You deserve kindness, patience, and love.',
    "I'm grateful for you, even on the days I fail to show it well.",
    'Your heart matters to me.',
    "I hope today feels a little lighter for you.",
    'You are not hard to love. You are worth loving well.',
    "I'm rooting for your peace, even before I ask for mine.",
    'You make my world softer.',
    "I miss your voice, but I'll wait until you're ready.",
    'Thank you for being someone I never want to take for granted.'
  ],
  gallery: [
    {
      src: '/images/memory1.jpg',
      alt: 'Memory one',
      caption: 'A moment I want to remember'
    },
    {
      src: '/images/memory2.jpg',
      alt: 'Memory two',
      caption: 'One of our little memories'
    },
    {
      src: '/images/memory3.jpg',
      alt: 'Memory three',
      caption: 'A piece of our story'
    },
    {
      src: '/images/memory4.jpg',
      alt: 'Memory four',
      caption: 'Something that feels like us'
    }
  ],
  music: {
    label: 'Play Our Song',
    src: '/assets/our-song.mp3'
  }
};
